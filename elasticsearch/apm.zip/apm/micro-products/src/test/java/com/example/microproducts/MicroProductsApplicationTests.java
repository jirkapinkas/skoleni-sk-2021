package com.example.microproducts;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroProductsApplicationTests {

    @Test
    void contextLoads() {
    }

}
