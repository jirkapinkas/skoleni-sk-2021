package com.example.microproducts;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroProductsApplication {

    public static void main(String[] args) {
        SpringApplication.run(MicroProductsApplication.class, args);
    }

}
