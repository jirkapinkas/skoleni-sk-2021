# TODO:

1. Spustit build.cmd
2. Přejít na http://localhost:8080/constructEmail/1
3. Pro zastavení služeb zavolat:

		docker-compose down

4. Jaeger je k dispozici zde: http://localhost:16686

## Rozšíření: 

